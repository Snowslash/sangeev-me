# @sangeev/estate-ui

Versioned visual contract for Sangeev's public web estate.

Main-site header candidate: `2.0.0-alpha.7`. Only `sangeev.me` adopts it; Casebook stays on `2.0.0-alpha.6` and Op notes, Scratchpad and AlignEd stay on `2.0.0-alpha.4`. This is not a coordinated rollout.

The package owns the selected Evidence Window × Drenched Atlas × Field Ledger shared surface: tokens, local fonts, estate header/theme behavior, named shell variants, title roles, registration rule, safety boundary, evidence frame, focus and reduced-motion behavior.

Dark mode uses **Deep Atlas**: `#061e1d` canvas, `#041615` chrome, `#0b2b29` panels and `#123a37` raised surfaces. Primary and secondary text are `#d4e3df` and `#9bb8b1`. Coral remains exactly `#ff7a66` in both themes, with dark ink labels on coral fills. Light mode retains its existing palette.

Use semantic roles for theme-aware application surfaces. The original `--estate-atlas`, `--estate-deep`, `--estate-mist` and other base colours are deliberately invariant; they are not a dark-mode mapping. New `--estate-night*` primitives back dark semantic roles, while `--estate-rule` distinguishes decorative dividers from accessible `--border`/`--input` edges. `--estate-link` is readable text, never a large surface fill. Paired boundary/chrome roles prevent pale islands and preserve contrast. Private/native adapters must translate these same roles and be verified separately; installing this React/CSS package cannot update a native app or remote desktop theme.

It deliberately does not contain application-specific workflows or page bodies.

Every consumer must call `initialiseEstateTheme()` before its first React render, then use `useEstateTheme()` for the shared toggle. `PublicEstateHeader` accepts optional `navigation: "full" | "projects"` (default `"full"`). Only the main site opts into `navigation="projects"`, rendering exactly Projects and GitHub while retaining the wordmark and theme toggle. Default and explicit `"full"` retain all five links. CSS changes only its version marker; tokens, geometry, fonts, focus and theme behavior are unchanged. Casebook uses `current="casebook"` without adding a shared navigation destination or activating a sibling; its current landing and app routing is documented in `OPERATIONS.md`.

The repository remains private and the package is not npm-published (`private: true`). First-party code is licensed under MIT (see `LICENSE`); the archive is intentionally distributable in public Casebook. Bundled fonts remain under their upstream OFL terms in `LICENSES/`. Do not run `pack:estate`, `release:stage` or `release:check` for this candidate: those legacy fleet workflows copy/install/build across sibling repositories. Use `npm pack --ignore-scripts --pack-destination <scratch-directory>` twice and compare SHA-256 instead.

The manifest's top-level artifact describes the alpha.4 baseline. Casebook and the main site have explicit per-site `artifact` overrides. Source, integration and browser checks use per-site expectations; an aggregate pass does not mean every app runs the candidate. Default checks include all registered sites and require their exact registered artifacts.

For Casebook's retained alpha.6 artifact, its scoped verification commands remain (do not replace its archive with alpha.7):

```sh
ESTATE_AUDIT_SITE=casebook node --test tests/integration.test.mjs
ESTATE_AUDIT_SITE=casebook npm run audit:source
ESTATE_AUDIT_SITE=casebook npm run audit:browser -- /absolute/scratch/evidence
```

The browser command normally installs/builds **only the selected app**. To inspect an already built app without installs/builds, add `ESTATE_SKIP_PREPARE=1`. It checks the selected registered routes at 390×844 and 1536×1024, both themes (Casebook now includes `/` and `/app/`). For the main-site candidate, use `ESTATE_AUDIT_SITE=sangeev.me` with the same three commands after its owner installs alpha.7. The browser gate asserts exact two-link main-site navigation and original five-link navigation everywhere else, without relaxing geometry, focus or theme checks. The browser selector accepts individual sites/routes, not `fleet`.
