# Estate design contract

## Selected language

- Evidence Window: bounded evidence and content-honesty posture.
- Drenched Atlas: teal, pale evidence surfaces and coral registration/focus.
- Field Ledger: Literata identity/headings and Atkinson Hyperlegible Next body/UI.

## Shared invariants

- exact tokens, font files and licence texts;
- header, theme control and cross-subdomain theme persistence;
- focus ring, target floor and reduced-motion behavior;
- title and section-heading roles;
- registration rule, safety boundary, evidence frame and primary-action geometry;
- named shell variants rather than local width values.

## Named layouts

- `landing`: project index and static project-note pages; standard 1180px rail.
- `standard-app`: normal functional tools; standard 1180px rail with app title scale.
- `wide-app`: dense functional tools such as AlignEd; 1480px rail with the same chrome and app title scale.

## Non-goals

The package does not own forms, workflow stages, cards, records, generated clinical text, persistence or application state. Those remain in their canonical repositories.
