import type { ElementType, HTMLAttributes, ReactNode } from "react";

export type EstateTheme = "light" | "dark";
export type EstatePage = "home" | "opnotes" | "scratchpad" | "aligned";
export type EstateLayoutVariant = "landing" | "standard-app" | "wide-app";
export type EstateTitleVariant = "landing" | "app";

export const ESTATE_UI_VERSION: "2.0.0-alpha.3";
export const ESTATE_THEME_STORAGE_KEY: "sangeevSiteTheme";
export const ESTATE_LAYOUT_VARIANTS: readonly EstateLayoutVariant[];

export function resolveEstateTheme(options?: { cookie?: string; storageValue?: string | null; prefersDark?: boolean }): EstateTheme;
export function getAppliedEstateTheme(environment?: typeof globalThis): EstateTheme;
export function applyEstateTheme(theme: EstateTheme, environment?: typeof globalThis, persist?: boolean): EstateTheme;
export function initialiseEstateTheme(environment?: typeof globalThis): EstateTheme;
export function useEstateTheme(): { theme: EstateTheme; toggleTheme: () => void };

export function ThemeToggle(props: { theme: EstateTheme; onToggle: () => void; className?: string }): ReactNode;
export function GitHubMark(props?: { size?: number; className?: string }): ReactNode;
export function PublicEstateHeader(props: { current: EstatePage; theme: EstateTheme; onToggleTheme: () => void; className?: string }): ReactNode;
export function EstateShell<T extends ElementType = "div">(props: HTMLAttributes<HTMLElement> & { variant: EstateLayoutVariant; as?: T; className?: string; children?: ReactNode }): ReactNode;
export function EstatePageTitle<T extends ElementType = "h1">(props: HTMLAttributes<HTMLElement> & { variant?: EstateTitleVariant; as?: T; className?: string; children?: ReactNode }): ReactNode;
export function EstateSectionTitle<T extends ElementType = "h2">(props: HTMLAttributes<HTMLElement> & { as?: T; className?: string; children?: ReactNode }): ReactNode;
export function EstateRegistrationRule(props: { className?: string }): ReactNode;
export function EstateBoundary<T extends ElementType = "aside">(props: HTMLAttributes<HTMLElement> & { label: string; variant?: "stack" | "grid"; as?: T; className?: string; children?: ReactNode }): ReactNode;
export function EstateEvidenceFrame<T extends ElementType = "figure">(props: HTMLAttributes<HTMLElement> & { as?: T; className?: string; children?: ReactNode }): ReactNode;
