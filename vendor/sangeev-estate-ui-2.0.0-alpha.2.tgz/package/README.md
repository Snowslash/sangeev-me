# @sangeev/estate-ui

Versioned visual contract for Sangeev's public web estate.

Current version: `2.0.0-alpha.2`.

The package owns the selected Evidence Window × Drenched Atlas × Field Ledger shared surface: tokens, local fonts, estate header/theme behavior, named shell variants, title roles, registration rule, safety boundary, evidence frame, focus and reduced-motion behavior.

It deliberately does not contain application-specific workflows or page bodies.

Every consumer must call `initialiseEstateTheme()` before its first React render, then use `useEstateTheme()` for the shared toggle. The central source audit enforces that bootstrap contract in all four current applications.

This package is local-only and unpublished. `npm run pack:estate` only creates and copies one reproducible tarball. `npm run release:stage` then reinstalls that exact artifact in every consumer, updates lockfiles and runs the full cross-estate release gate. Neither command commits, pushes or deploys.
