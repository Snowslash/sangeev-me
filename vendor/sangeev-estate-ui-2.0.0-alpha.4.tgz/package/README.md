# @sangeev/estate-ui

Versioned visual contract for Sangeev's public web estate.

Current version: `2.0.0-alpha.4`.

The package owns the selected Evidence Window × Drenched Atlas × Field Ledger shared surface: tokens, local fonts, estate header/theme behavior, named shell variants, title roles, registration rule, safety boundary, evidence frame, focus and reduced-motion behavior.

Dark mode uses **Deep Atlas**: `#061e1d` canvas, `#041615` chrome, `#0b2b29` panels and `#123a37` raised surfaces. Primary and secondary text are `#d4e3df` and `#9bb8b1`. Coral remains exactly `#ff7a66` in both themes, with dark ink labels on coral fills. Light mode retains its existing palette.

Use semantic roles for theme-aware application surfaces. The original `--estate-atlas`, `--estate-deep`, `--estate-mist` and other base colours are deliberately invariant; they are not a dark-mode mapping. New `--estate-night*` primitives back dark semantic roles, while `--estate-rule` distinguishes decorative dividers from accessible `--border`/`--input` edges. `--estate-link` is readable text, never a large surface fill. Paired boundary/chrome roles prevent pale islands and preserve contrast. Private/native adapters must translate these same roles and be verified separately; installing this React/CSS package cannot update a native app or remote desktop theme.

It deliberately does not contain application-specific workflows or page bodies.

Every consumer must call `initialiseEstateTheme()` before its first React render, then use `useEstateTheme()` for the shared toggle. The central source audit enforces that bootstrap contract in all four current applications.

This package is local-only and unpublished. `npm run pack:estate` only creates and copies one reproducible tarball. `npm run release:stage` then reinstalls that exact artifact in every consumer, updates lockfiles and runs the full cross-estate release gate. Neither command commits, pushes or deploys.
